#!/usr/bin/env bash

rm -rf temp
python -m unittest test_*.py