phobos scenes module
-------------------

In this modules robots are wrapped as entities to arrange them then in scenes or assemblies.

Submodules
----------

phobos.scenes.entity module
```````````````````````````

.. automodule:: phobos.scenes.entity
    :members:
    :undoc-members:
    :show-inheritance:

phobos.scenes.assembly module
`````````````````````````````

.. automodule:: phobos.scenes.assembly
    :members:
    :undoc-members:
    :show-inheritance:

phobos.scenes.scene module
``````````````````````````

.. automodule:: phobos.scenes.scene
    :members:
    :undoc-members:
    :show-inheritance: