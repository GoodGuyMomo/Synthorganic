phobos utils module
-------------------

Submodules
----------

phobos.utils.commandline_logging module
```````````````````````````````````````

.. automodule:: phobos.utils.commandline_logging
    :members:
    :undoc-members:
    :show-inheritance:

phobos.utils.git module
```````````````````````

.. automodule:: phobos.utils.git
    :members:
    :undoc-members:
    :show-inheritance:

phobos.utils.hyrodyn module
```````````````````````````

.. automodule:: phobos.utils.hyrodyn
    :members:
    :undoc-members:
    :show-inheritance:


phobos.utils.inertia module
```````````````````````````

.. automodule:: phobos.utils.inertia
    :members:
    :undoc-members:
    :show-inheritance:

phobos.utils.misc module
````````````````````````

.. automodule:: phobos.utils.misc
    :members:
    :undoc-members:
    :show-inheritance:

phobos.utils.xml module
```````````````````````

.. automodule:: phobos.utils.xml
    :members:
    :undoc-members:
    :show-inheritance:

phobos.utils.transform module
`````````````````````````````

.. automodule:: phobos.utils.transform
    :members:
    :undoc-members:
    :show-inheritance:

phobos.utils.tree module
````````````````````````

.. automodule:: phobos.utils.tree
    :members:
    :undoc-members:
    :show-inheritance: