phobos blender package
======================

Subpackages
-----------

.. toctree::
    :maxdepth: 3

    phobos.blender.io
    phobos.blender.model
    phobos.blender.operators
    phobos.blender.utils

Submodules
----------

phobos.defs module
``````````````````

.. automodule:: phobos.blender.defs
    :members:
    :undoc-members:
    :show-inheritance:

phobos.display module
`````````````````````

.. automodule:: phobos.blender.display
    :members:
    :undoc-members:
    :show-inheritance:

phobos.phobosgui module
```````````````````````

.. automodule:: phobos.blender.phobosgui
    :members:
    :undoc-members:
    :show-inheritance:

phobos.phoboslog module
```````````````````````

.. automodule:: phobos.blender.phoboslog
    :members:
    :undoc-members:
    :show-inheritance:

phobos.phobossystem module
``````````````````````````

.. automodule:: phobos.blender.phobossystem
    :members:
    :undoc-members:
    :show-inheritance:

Module contents
---------------

.. automodule:: phobos.blender
    :members:
    :undoc-members:
    :show-inheritance:
